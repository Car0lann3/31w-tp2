# Thème collège de maisonneuve
### Développement d'un site constitué de plusieurs modèles,  gabarits de modèle et modèle de page «template» utilisant les champs personnalisés et plusieurs animations/transitions Javascript/CSS 

Accéder au Site web: 
[SiteGround](Mots de passe perdu)

Accéder à la github page:
[Github page](https://github.com/Car0lann3/wp-cdc)

Pour plus d'information sur la conception de thème
[wp developper guide](https://developer.wordpress.org/)

![alt text](./public/517.jpg)
