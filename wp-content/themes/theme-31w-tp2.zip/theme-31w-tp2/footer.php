<footer class="site__footer">
<h2>Le pied de page</h2>
</footer>
<?php wp_footer(); ?>
</section> <!-- fin .site -->
</body>
</html>