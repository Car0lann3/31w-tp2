<?php get_header(); ?> 
<h1>ERREUR 404</h1>
   
<?php get_footer(); ?>